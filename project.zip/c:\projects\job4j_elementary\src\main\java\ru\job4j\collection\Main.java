package ru.job4j.collection;

public class Main {
}
