package ru.job4j.oop;

public class Hare {
    public void eat(Bun bun) {

    }
}
