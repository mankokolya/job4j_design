package ru.job4j.exception;

public class UserInputException extends Exception {
    public UserInputException(String message) {
        super(message);
    }
}
