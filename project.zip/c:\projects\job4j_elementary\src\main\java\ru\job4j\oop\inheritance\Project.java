package ru.job4j.oop.inheritance;

public class Project {
    private String project;

    public Project(String project) {
        this.project = project;
    }

    public String getProject() {
        return project;
    }
}
