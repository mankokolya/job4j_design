[![Build Status](https://travis-ci.org/mankokolya/job4j_design.svg?branch=master)](https://travis-ci.org/mankokolya/job4j_design)
[![codecov](https://codecov.io/gh/mankokolya/job4j_design/branch/master/graph/badge.svg)](https://codecov.io/gh/mankokolya/job4j_design)
# job4j_design
