package ru.job4j.oop;

public class Car extends Transport {
}
