package ru.job4j.oop.inheritance;

public class Diagnose {
    private String diagnose;

    public String getDiagnose() {
        return diagnose;
    }

    public void setDiagnose(String diagnose) {
        this.diagnose = diagnose;
    }
}
