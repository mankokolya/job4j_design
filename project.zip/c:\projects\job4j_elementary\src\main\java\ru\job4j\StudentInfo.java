package ru.job4j;

public class StudentInfo {
    public static void main(String[] args) {
        System.out.println("Mykola Manko");
        System.out.println("14.12.1990");
    }
}
