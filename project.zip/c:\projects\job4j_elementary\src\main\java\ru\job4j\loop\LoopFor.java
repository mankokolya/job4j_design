package ru.job4j.loop;

public class LoopFor {
    public static void main(String[] args) {
        for (int i = 5; i < 11; i++) {
            System.out.println(i);
        }
    }
}
