package ru.job4j.exception;

public class FrequentEx {
    public static void main(String[] args) {
        String[] shops = {"Ebay", "Amazon", "Ozon"};
        for (int i = 0; i < shops.length; i++) {
            System.out.println(shops[i]);
        }
    }
}
