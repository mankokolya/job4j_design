package ru.job4j.puzzle;

public class LogicTest {
}