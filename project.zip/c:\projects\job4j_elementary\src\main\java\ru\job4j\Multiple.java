package ru.job4j;

public class Multiple {
    public static void main(String[] args) {
        System.out.println("1 * 2 = 2");
        System.out.println("1 * 3 = 3");
        System.out.println("1 * 4 = 4");
        System.out.println("1 * 9 = 9");
    }
}
