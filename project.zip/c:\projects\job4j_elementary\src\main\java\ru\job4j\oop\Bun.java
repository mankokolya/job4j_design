package ru.job4j.oop;

public class Bun {
    public void runAway() {

    }

    public void sing() {

    }
}
