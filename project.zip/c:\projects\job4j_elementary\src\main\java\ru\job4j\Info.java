package ru.job4j;

public class Info {
    public static void main(String[] args) {
        System.out.println("17.04.2020");
    }
}
