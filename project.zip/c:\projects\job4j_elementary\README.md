[![codecov](https://codecov.io/gh/mankokolya/job4j_elementary/branch/master/graph/badge.svg)](https://codecov.io/gh/mankokolya/job4j_elementary)
[![Build Status](https://travis-ci.org/mankokolya/job4j_elementary.svg?branch=master)](https://travis-ci.org/mankokolya/job4j_elementary)

# job4j
Проект содержит решения блока "Базовый синтаксис" курса Job4j.